<template>
    <nav class="navbar navbar-expand-lg fixed-top" id="navbar">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"><i class="fa fa-navicon" style="color:black; font-size:28px;"></i></span>
            </button>
            <router-link class="navbar-brand " to="/"><img src="../assets/images/logo1.png" class="logo"></router-link>
            <router-link class="nav-link gh" to="/Signup"><i class="fa fa-sign-in"></i></router-link>
        
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto left-nav-link">
                    <li class="nav-item">
                        <router-link class="nav-link" to="/">Home</router-link>
                    </li>
                    <li class="nav-item">
                        <router-link class="nav-link" to="/Courses">Courses</router-link>
                    </li>
                    <li class="nav-item">
                        <router-link class="nav-link" to="/Announcement">Announcement</router-link>
                    </li>
                    <li class="nav-item">
                        <router-link class="nav-link" to="/Contactus">Contact Us</router-link>
                    </li>
                </ul>
                <form class="search-bar">
                    <input class="text" type="search" placeholder="Search" aria-label="Search">
                    <button class="" type="submit"><i class="fa fa-search"></i></button>
                </form>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item gh1">
                        <router-link class="nav-link" to="/Login">Log in / Sign Up</router-link>
                    </li>
                    <!-- <li class="nav-item gh1">
                        <router-link class="nav-link" to="/Signup">Sign up</router-link>
                    </li> -->
                </ul>
            </div>
        </div>
    </nav>
</template>

<script>

export default {
    name: "NavbarView",
}
</script>

<style scoped>
.logo {
    width: 100px;
    height: 35px;
}

nav {
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2);
}

li {
    font-family: "Times New Roman", Times, serif;
    font-size: 20px;

}

.navbar {
    background: #EFF5FC 0% 0% no-repeat padding-box;
    opacity: 1;
    padding: 20px;

}
.left-nav-link .nav-link {
    color: #707070;
    font-family: 'Noto Sans', sans-serif;
    font-size: 16px;
    text-indent: 20px;
}
.nav-link {
    color: #707070;
    font-family: 'Noto Sans', sans-serif;
    font-size: 16px;
    
}

li>a {
    position: relative;
    color: #595959;
    text-decoration: none;
}

li>a:hover {
    color: #595959;
}

li>a:before {
    content: "";
    position: absolute;
    width: 100%;
    height: 2px;
    bottom: 0;
    left: 0;
    background-color: #595959;
    visibility: hidden;
    -webkit-transform: scaleX(0);
    transform: scaleX(0);
    -webkit-transition: all 0.3s ease-in-out 0s;
    transition: all 0.3s ease-in-out 0s;
}

li>a:hover:before {
    visibility: visible;
    -webkit-transform: scaleX(1);
    transform: scaleX(1);
}
.left-nav-link .nav-link {
    position: relative;
    color: #595959;
    text-decoration: none;
}

.left-nav-link .nav-link:hover {
    color: #595959;
}

.left-nav-link .nav-link:before {
    content: "";
    position: absolute;
    width: 100%;
    height: 2px;
    bottom: 0;
    left: 10px;
    background-color: #595959;
    visibility: hidden;
    -webkit-transform: scaleX(0);
    transform: scaleX(0);
    -webkit-transition: all 0.3s ease-in-out 0s;
    transition: all 0.3s ease-in-out 0s;
}

.left-nav-link .nav-link:hover:before {
    visibility: visible;
    -webkit-transform: scaleX(1);
    transform: scaleX(1);
}

.gh {
    font-size: 30px;
    display: none;
}

.gh1 {
    display: block;
}

@media screen and (max-width: 768px) {
    .gh {
        display: block;
    }

    .gh1 {
        display: none;
    }
    .search-bar{
        justify-content: space-between;
        margin-right:0 !important;

    }
    
    .parent_blocks{
justify-content: center;
    }
   
}
@media (min-width: 768px) and (max-width: 992.92px) {
    .search-bar{
        justify-content: space-between;
    margin-right: 0 !important;
    }
}
.search-bar button i {
    width: 25px;
    outline: none;

}

.search-bar {
    background: #FFFFFF7D 0% 0% no-repeat padding-box;
    display: flex;
    align-items: center;
    border-radius: 5px;
    border: 1px solid #D4D4D4;
    padding: 10px;
    /* backdrop-filter: blur(4px) saturate(180%); */
    margin-right: 20px;
}

.search-bar input {
    background: transparent;

    border: 0;
    outline: none;

    font-size: 14px;
    color: #D4D4D4;
}

.search-bar button {
    border: 0;
    border-radius: 50%;
    width: 35px;
    height: 35px;
    background-color: none;
    background: #58629b;
    cursor: pointer;
}

.search-bar button i {
    width: 25px;
    color: #fff;
    position: relative;
    left: -12px;
    top: -3px;
}
.container-fluid{
    max-width: 1350px;
    margin:0 auto;
}
</style>