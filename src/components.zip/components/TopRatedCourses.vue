<template>
    <div class="category-test pt-3">
        <div class="container">
            <h4 class="academic_head_text">

                <span id="aca_text">Top</span>Rated Courses
                <router-link to="#">See all</router-link>
            </h4>
        </div>


    </div>
    <div class="container-fluid mb">
        <div class="row mt-4">
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">JAVA Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data
                            types, object, and other core Java concepts.</p>
                        <div class="text-left price">
                            <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            <a href="#" class="btn btn-primary">Buy Now</a>

                        </div>
                    </div>
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">JAVA Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data
                            types, object, and other core Java concepts.</p>
                        <div class="text-left price">
                            <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            <a href="#" class="btn btn-primary">Buy Now</a>

                        </div>
                    </div>
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">JAVA Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data
                            types, object, and other core Java concepts.</p>
                        <div class="text-left price">
                            <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            <a href="#" class="btn btn-primary">Buy Now</a>

                        </div>
                    </div>
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">JAVA Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data
                            types, object, and other core Java concepts.</p>
                        <div class="text-left price">
                            <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            <a href="#" class="btn btn-primary">Buy Now</a>

                        </div>
                    </div>
                </router-link>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'TopRatedCourses'
}
</script>



<style scoped>
.category-test a {
    text-decoration: none;
}

.category-test h4 a {
    float: right;
    color: #0d4b7e;
    font-size: 17px;
    font-family: 'Noto Sans', sans-serif;
  
}

/* .box .offer {
    width: 100px;
    height: 20px;
    position: relative;
    top: -177px;
    left: -5px;
    font-size: 12px;
} */
/* .offer-details {
    font-size: 12px;
    color: white;
    position: relative;
    top: -179px;
    left: -85px;
} */
/* .btn-warning {
    color: #fff;
    background-color: #f0ad4e;
    border-color: #eea236;
}
.btn {
    position: relative;
    left: 15%;
} */
/* .wr {
    position: relative;
    left: 9px;
    top: -4px;
    font-size: 12px;
} */
/* .box  offer {
    position: absolute;
    width: 10%;
    height: 7%;
    top: -10px;
    left: -4px;
    font-size: 12px;
} */

/* .box .card-text {
    font-size: 16px;
    font-family: 'Times New Roman', Times, serif;
    color: black;
} */
/* 
.box .card-title {
    font-size: 18px;
    font-family: 'Times New Roman', Times, serif;
    font-weight: bold;
    color: black;
    margin-top: -20px;
} */

.box .star {
    color: orange;
    position: relative;
    top: -13px;
    left: 14px;
    letter-spacing: 2px;
}

.mb .row {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    flex-wrap: wrap;
    margin-left: 0px;
    margin-right: 0px;
}

.box {

    height: auto;
    /* UI Properties */
    width: 24%;
    /* border: 1px solid #FFFFFF; */
    cursor: pointer;
    background: #FFFFFF 0% 0% no-repeat padding-box;
    box-shadow: 0px 3px 6px #00000029;
    border-radius: 4px;
    opacity: 1;
    margin-bottom: 3%;
    

}

.box .row {
    padding: 12px 10px;
}



@media screen and (max-width: 600px) {
    .box {
        width: 100%;
        margin-bottom: 35px;
    }

    .box .offer {
        position: absolute;
        top: -13px;
    }

    .offer-details {
        position: relative;
        top: -200px;
    }

    .academic_head_text {
        font-size: 15px !important;
        padding-left: 0 !important;

    }

    .category-test h4 a {
        padding-right: 0;
        font-size: 15px !important;
    }
}

@media only screen and (min-width: 600px) and (max-width: 912px) {
    .box {
        width: 47%;
        margin-bottom: 35px;
    }
}

@media only screen and (min-width: 950px) and (max-width: 1024px) {
    .box {
        width: 30%;
        margin-bottom: 3%;
    }
}

@media (min-width: 768px) and (max-width: 991.92px) {
    .academic_head_text {
        font-size: 20px;
    }

}

.price p {
    color: black;
    float: left;
    width: 35%;
}

.price a {
    width: 60%;
    float: right;

}

.offer {
    position: absolute;
    width: 90px;
    height: 10px;
    top: -12px;
    left: -5px;

}

.offer-details {
    position: absolute;
    top: -10px;
    left: 5px;
    color: white;
    font-size: 14px;
}

.wer {
    position: relative;
}

.academic_head_text {
    color: #006acd;
    /* padding-left:20px; */
    font-size: 20px;

}


#aca_text {
    color: #006acd;
    font-weight: bold;
    padding-right: 10px;
}
.box .card-text {
    font: var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-normal) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-21) var(--unnamed-font-family-segoe-ui);
    letter-spacing: var(--unnamed-character-spacing-0);
    text-align: left;
    font: normal normal normal 16px/21px Segoe UI;
    letter-spacing: 0px;
    color: #666666;
    opacity: 1;
}
.box .card-title {
    margin-top: -20px;
    font: var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-600) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-21) var(--unnamed-font-family-segoe-ui);
    letter-spacing: var(--unnamed-character-spacing-0);
    text-align: left;
    font: normal normal 600 16px/21px Segoe UI;
    letter-spacing: 0px;
    color: #666666;
    opacity: 1;
}
</style>

