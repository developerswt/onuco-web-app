<template>
    <div class="category-test mt-5 ">

        <h4 class="academic_head_text">

            <span id="aca_text">Top</span>Rated Academics
            <router-link to="#">See all</router-link>
        </h4>
    </div>
    <div class="container-fluid mb">
        <div class="row mt-5">
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">JAVA Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data
                            types, object, and other core Java concepts.</p>
                        <div class="text-left price">
                            <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            <a href="#" class="btn btn-primary">Buy Now</a>

                        </div>
                    </div>
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">JAVA Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data
                            types, object, and other core Java concepts.</p>
                        <div class="text-left price">
                            <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            <a href="#" class="btn btn-primary">Buy Now</a>

                        </div>
                    </div>
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">JAVA Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data
                            types, object, and other core Java concepts.</p>
                        <div class="text-left price">
                            <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            <a href="#" class="btn btn-primary">Buy Now</a>

                        </div>
                    </div>
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">JAVA Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data
                            types, object, and other core Java concepts.</p>
                        <div class="text-left price">
                            <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            <a href="#" class="btn btn-primary">Buy Now</a>

                        </div>
                    </div>
                </router-link>
            </div>
        </div>
    </div>
    <!-- <div class="container">
        <div class="row pt-4">
            <div class="col-md-3">
                <div class="card" style="width: 100%; height: 100%;">
                    <img class="card-img-top" src="../assets/images/java.jpg" alt="Card image cap">
                    <div class="">
                        <img src="../assets/images/offer.png" class="offer">
                        <font class="offer-details"><b>20 % OFF</b></font>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">JAVA Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data types, object, and other core Java concepts.</p>
                        <div class="row text-left">
                            <div class="col-md-4">
                                <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            </div>
                            <div class="col-md-7">
                                <a href="#" class="btn btn-primary">Buy Now</a>
                            </div>
                        </div>        
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="width: 100%; height: 100%;">
                    <img class="card-img-top" src="../assets/images/java.jpg" alt="Card image cap">
                    <div class="">
                        <img src="../assets/images/offer.png" class="offer">
                        <font class="offer-details"><b>20 % OFF</b></font>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Python Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data types, object, and other core Java concepts.</p>
                        <div class="row text-left">
                            <div class="col-md-4">
                                <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            </div>
                            <div class="col-md-7">
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                        </div>        
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="width: 100%; height: 100%;">
                    <img class="card-img-top" src="../assets/images/java.jpg" alt="Card image cap">
                    <div class="">
                        <img src="../assets/images/offer.png" class="offer">
                        <font class="offer-details"><b>20 % OFF</b></font>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">CSS3 Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data types, object, and other core Java concepts.</p>
                        <div class="row text-left">
                            <div class="col-md-4">
                                <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            </div>
                            <div class="col-md-7">
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                        </div>       
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="width: 100%; height: 100%;">
                    <img class="card-img-top" src="../assets/images/java.jpg" alt="Card image cap">
                    <div class="">
                        <img src="../assets/images/offer.png" class="offer">
                        <font class="offer-details"><b>20 % OFF</b></font>
                    </div>
                    <div class="star">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">JavaScript Language</h5>
                        <p class="card-text">This course covers the basics of Java, Class, Files, error handling, data types, object, and other core Java concepts.</p>
                        <div class="row text-left">
                            <div class="col-md-4">
                                <p><b>&#8377;1999</b>
                                &#8377;<del>2099</del></p>
                            </div>
                            <div class="col-md-7">
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                        </div>        
                    </div>
                </div>
            </div>
        </div>
    </div>    -->
</template>

<script>
export default {
    name: 'TopRatedCourses'
}
</script>



<style scoped>
.category-test a {
    text-decoration: none;
}

.category-test h4 a {
    float: right;
    color: #0d4b7e;
    font-size: 17px;
    font-family: 'Noto Sans', sans-serif;
}

/* .box .offer {
    width: 100px;
    height: 20px;
    position: relative;
    top: -177px;
    left: -5px;
    font-size: 12px;
} */
/* .offer-details {
    font-size: 12px;
    color: white;
    position: relative;
    top: -179px;
    left: -85px;
} */
/* .btn-warning {
    color: #fff;
    background-color: #f0ad4e;
    border-color: #eea236;
}
.btn {
    position: relative;
    left: 15%;
} */
/* .wr {
    position: relative;
    left: 9px;
    top: -4px;
    font-size: 12px;
} */
/* .box  offer {
    position: absolute;
    width: 10%;
    height: 7%;
    top: -10px;
    left: -4px;
    font-size: 12px;
} */

.box .card-text {
    font-size: 16px;
    font-family: 'Times New Roman', Times, serif;
    color: black;
}

.box .card-title {
    font-size: 18px;
    font-family: 'Times New Roman', Times, serif;
    font-weight: bold;
    color: black;
    margin-top: -20px;
}

.box .star {
    color: orange;
    position: relative;
    top: -13px;
    left: 14px;
    letter-spacing: 2px;
}

.mb .row {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    flex-wrap: wrap;
    margin-left: 0px;
    margin-right: 0px;
}

.box {
    top: 168px;
    left: 697px;
    height: auto;
    /* UI Properties */
    width: 24%;
    border: 1px solid #FFFFFF;
    cursor: pointer;
    border: 1px solid black;
    margin-bottom: 3%;

}

.box .row {
    padding: 12px 10px;
}



@media screen and (max-width: 600px) {
    .box {
        width: 100%;
        margin-bottom: 35px;
    }

    .box .offer {
        position: absolute;
    top: -13px;
    }

    .offer-details {
        position: relative;
        top: -200px;
    }
    .academic_head_text{
        font-size: 18px;
        padding-left:0 !important;

    }
}

@media only screen and (min-width: 600px) and (max-width: 912px) {
    .box {
        width: 47%;
        margin-bottom: 35px;
    }
}

@media only screen and (min-width: 950px) and (max-width: 1024px) {
    .box {
        width: 30%;
        margin-bottom: 3%;
    }
}
@media (min-width: 768px) and (max-width: 991.92px) {
    .academic_head_text{
        font-size: 20px ;
    }
    
}

.price p {
    color: black;
    float: left;
    width: 35%;
}

.price a {
    width: 50%;
    margin-left: 10%;

}

.offer {
    position: absolute;
    width: 90px;
    height: 10px;
    top: -12px;
    left: -5px;

}

.offer-details {
    position: absolute;
    top: -10px;
    left: 5px;
    color: white;
    font-size: 14px;
}

.wer {
    position: relative;
}

.academic_head_text {
    color: #006acd;
    padding-left:20px;

}


#aca_text {
    color: #006acd;
    font-weight: bold;
    padding-right: 10px;
}

</style>

