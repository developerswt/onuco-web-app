<template>
    <div class="container-fluid jk">
        <div class="Instructor_parent_block">
            <h2 class="instructor_head_text"><span id="Meet_text">Meet</span> Instructor</h2>
            <section>
                <div class="instructor-details">
                    <div class="professor-block">
                        <div class="row">

                            <div class="col-md-5 col-lg-5">
                                <div class="row">
                                    <div class="col-lg-4 col-4 col-sm-4">
                                        <div class="professor_image_block">
                                            <img src="../assets/images/Mask Group 1.png" class="img-fluid">
                                        </div>

                                    </div>
                                    <div class="col-lg-8 col-8 col-sm-8">
                                        <h5 id="prof_text">Dr. Vijaya Kumar B.P</h5>
                                        <p class="rating_icons"><i class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                class="fa fa-star-o"></i> (23 reviews) </p>
                                        <div class="social-icons">
                                            <a href="#" class="fa fa-facebook"></a>
                                            <a href="#" class="fa fa-twitter"></a>
                                            <a href="#" class="fa fa-linkedin"></a>

                                        </div>
                                    </div>
                                </div>


                            </div>
                            <div class="col-md-7 col-lg-7">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="share_icon_block">
                                            <img src="../assets/images/share.png" class="share-icon">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="btn-group">
                                            <button type="button" class="btn" id="left_button">13 Following</button>
                                            <button type="button" class="btn" id="right_button">1200 Follwers</button>
                                        </div>
                                    </div>
                                </div>


                            </div>

                        </div>

                    </div>
                    <div class="row professor-details">
                        <div class="col-sm-12 col-lg-12">
                            <p class="professor-details_text">VIJAY KUMAR B. P. Received the Ph. D degree in Electrical
                                Communication Engg., Department
                                from Indian Institute of Science (IISc), Bangalore in 2003, M.Tech degree in Computer
                                Science and Technology from Indian Institute of Technology, Roorkee (IITR), with honors in
                                1992 and Bachelor’s degree in Electronics and Communications from Mysore University with
                                Distinction in the year 1987. With a proven success record of boosting leadership actions
                                over 33 years of extensive teaching and research experience including 25 years of
                                administrative experience. He is currently a professor and Head R & D, Industry Interaction
                                coordinator, Information Science and Engg., Dept., M S Ramaiah Institute of Technology,
                                Bangalore, Karnataka, India, where he is involved in research and teaching UG and PG
                                students, and his major area of research are Computational Intelligence (Machine Learning)
                                applications in Mobile, IoT, Sensor networks, Big data, Cognitive Computing applications and
                                Software Quality Engineering.</p>
                        </div>
                    </div>
                </div>
            </section>
            <section id="Course_section">
                <h5 class="course_text"><span id="course_text">Courses</span> (230)</h5>
                <div class="row">
                    <div class="col-md-6 col-lg-3">
                        <router-link to="/SemesterDetails">
                            <div class="card">
                                <div class="card-title">
                                    <div class="row">
                                        <div class="col-md-12 ">

                                            <div class="card_top_text">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <p><b>Math 1 (NEP Series)</b></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <img src="../assets/images/share.png" class="icon">
                                                    </div>
                                                    <div class="col-lg-6 col-6 col-sm-6">
                                                        <p> 18CS81</p>
                                                    </div>
                                                    <div class="col-lg-6 col-6 col-sm-6">
                                                        <p id="small_text">240
                                                            hrs</p>
                                                    </div>
                                                    <div class="col-lg-8 col-9 col-sm-9">

                                                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Esse,
                                                            excepturi.</p>
                                                    </div>
                                                    <div class="col-lg-4 col-3 col-sm-3">
                                                        <div class="video_logo">
                                                            <img src="../assets/images/video.png" class="video">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <p class="sub_icons"><i class="fa fa-star"></i><i
                                                                class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                                class="fa fa-star"></i><i class="fa fa-star-o"></i>
                                                            (23
                                                            reviews) </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </router-link>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <router-link to="/SemesterDetails">
                            <div class="card">
                                <div class="card-title">
                                    <div class="row">
                                        <div class="col-md-12 ">

                                            <div class="card_top_text">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <p><b>Math 1 (NEP Series)</b></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <img src="../assets/images/share.png" class="icon">
                                                    </div>
                                                    <div class="col-lg-6 col-6 col-sm-6">
                                                        <p> 18CS81</p>
                                                    </div>
                                                    <div class="col-lg-6 col-6 col-sm-6">
                                                        <p id="small_text">240
                                                            hrs</p>
                                                    </div>
                                                    <div class="col-lg-8 col-9 col-sm-9">

                                                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Esse,
                                                            excepturi.</p>
                                                    </div>
                                                    <div class="col-lg-4 col-3 col-sm-3">
                                                        <div class="video_logo">
                                                            <img src="../assets/images/video.png" class="video">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <p class="sub_icons"><i class="fa fa-star"></i><i
                                                                class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                                class="fa fa-star"></i><i class="fa fa-star-o"></i>
                                                            (23
                                                            reviews) </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </router-link>
                    </div>
                </div>
            </section>
            <section id="non_course_section">
                <h5 class="course_text"><span id="course_text">Non-Academic Courses</span> (10)</h5>
                <div class="row">
                    <div class="col-md-6 col-lg-3">
                        <router-link to="/SemesterDetails">
                            <div class="card">
                                <div class="card-title">
                                    <div class="row">
                                        <div class="col-md-12 ">

                                            <div class="card_top_text">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <p><b>Math 1 (NEP Series)</b></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <img src="../assets/images/share.png" class="icon">
                                                    </div>
                                                    <div class="col-lg-6 col-6 col-sm-6">
                                                        <p> 18CS81</p>
                                                    </div>
                                                    <div class="col-lg-6 col-6 col-sm-6">
                                                        <p id="small_text">240
                                                            hrs</p>
                                                    </div>
                                                    <div class="col-lg-8 col-9 col-sm-9">

                                                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Esse,
                                                            excepturi.</p>
                                                    </div>
                                                    <div class="col-lg-4 col-3 col-sm-3">
                                                        <div class="video_logo">
                                                            <img src="../assets/images/video.png" class="video">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <p class="sub_icons"><i class="fa fa-star"></i><i
                                                                class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                                class="fa fa-star"></i><i class="fa fa-star-o"></i>
                                                            (23
                                                            reviews) </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </router-link>
                    </div>

                    <div class="col-md-6 col-lg-3">
                        <router-link to="/SemesterDetails">
                            <div class="card">
                                <div class="card-title">
                                    <div class="row">
                                        <div class="col-md-12 ">

                                            <div class="card_top_text">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <p><b>Math 1 (NEP Series)</b></p>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <img src="../assets/images/share.png" class="icon">
                                                    </div>
                                                    <div class="col-lg-6 col-6 col-sm-6">
                                                        <p> 18CS81</p>
                                                    </div>
                                                    <div class="col-lg-6 col-6 col-sm-6">
                                                        <p id="small_text">240
                                                            hrs</p>
                                                    </div>
                                                    <div class="col-lg-8 col-9 col-sm-9">

                                                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Esse,
                                                            excepturi.</p>
                                                    </div>
                                                    <div class="col-lg-4 col-3 col-sm-3">
                                                        <div class="video_logo">
                                                            <img src="../assets/images/video.png" class="video">
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <p class="sub_icons"><i class="fa fa-star"></i><i
                                                                class="fa fa-star"></i><i class="fa fa-star"></i><i
                                                                class="fa fa-star"></i><i class="fa fa-star-o"></i>
                                                            (23
                                                            reviews) </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </router-link>
                    </div>
                </div>
            </section>
            <section id="tab_block">
                <el-tabs v-model="activeName" class="demo-tabs" @tab-click="handleClick">
                    <el-tab-pane label="OBJECTIVES" name="first">

                        <h2 class="Object_text"><img src="../assets/images/g2.png" class="img-fluid" /> OBJECTIVES</h2>

                        <p class="Sub_paragraph"><span id="Sub_text">Present Address:</span> Professor and Head, Information
                            Science Engg. Dept., MS Ramaiah Institute of Technology, Vidya Soudha, Bangalore -560054,
                            Karnataka, India.</p>
                        <p class="Sub_paragraph"><span id="Sub_text">Home Address:</span> # 014, C1 Block, Sumadhura Arcade
                            Apt., Sirsi Main Road, Hoodi Post, Bangalore - 560017</p>
                        <p class="Sub_paragraph"><span id="Sub_text">Phone:</span> (+91)-80-5260xxxx/ 5260xxxx /2360xxxx
                            Ext:
                            150 Mobile : +91-998063xxxx</p>
                        <p class="Sub_paragraph"><span id="Sub_text">Email:</span> vijayexm@edu.edu , vijayexm@yahoo.co.in
                        </p>
                        <p class="Sub_paragraph"><span id="Sub_text">Home Page:</span>edu.edu,
                            linkedin.com/in/vijaya-beekanahalli-9Ssasewb</p>


                        <div class="education_block">
                            <h2 class="Object_text"><img src="../assets/images/g2.png" class="img-fluid" /> EDUCATION
                            </h2>

                            <div class="row_class">
                                <p>2003</p>
                                <i class="fa fa-circle" style="color: #ffa500;"></i>
                                <div class="line_class">
                                </div>
                                <div class="div">
                                    <p id="education_text" class="mb-0">INDIAN INSTITUTE OF SCIENCE, BANGALORE, INDIA</p>
                                    <br>
                                    <p><span id="education_text">Ph.D </span>in Electrical Communication Engineering Dept.
                                        <br>
                                        <span id="education_text">CGPA: </span>7/8 (Research Training Programme)
                                    </p>
                                    <div class="ptext">
                                        <span id="education_text">Advisor: </span>Prof. P. Venkataram, Professor, Chief
                                        Program Executive, Protocol Engineering and Technology (PET) Unit, Electrical
                                        Communication Engineering Dept., Indian Institute of Science,
                                        Bangalore-560 012, INDIA.

                                    </div>

                                    <p><span id="education_text">Thesis: </span>Some of the Neural Network Applications in
                                        Mobile Networks. </p>
                                </div>

                            </div>

                            <div class="row_class">
                                <p>1992</p>
                                <i class="fa fa-circle" style="color: #ffa500;"></i>
                                <div class="line_class">
                                </div>
                                <div class="div">
                                    <p id="education_text" class="mb-0">INDIAN INSTITUTE OF TECHNOLOGY (University of
                                        Roorkee), UP, INDIA
                                    </p>
                                    <p class="mt-0">M. Tech in Computer science and Technology with honors, (75.75%)</p>
                                    <p><span id="education_text">Advisor: </span>Prof. A. K. Sarje and Prof. R. Thapar,
                                        Professor, EC Dept., IIT (UOR), Roorkee Thesis: Communication Protocol
                                        specification, verification and synthesis.
                                    </p>
                                </div>
                            </div>

                            <div class="row_class">
                                <p>1987</p>
                                <i class="fa fa-circle" style="color: #ffa500;"></i>

                                <div class="div">
                                    <p id="education_text" class="mb-0">MYSORE UNIVERSITY, MYSORE, KARNATAKA, INDIA</p>
                                    <p class="mt-0">Bachelor of Engineering in Electronics and Communication Engg., with
                                        Distinction.</p>

                                </div>
                            </div>
                        </div>

                        <div class="experience_block">
                            <h2 class="Object_text"><img src="../assets/images/g2.png" class="img-fluid" /> EXPERIENCE
                            </h2>
                            <div class="row" id="row_block">
                                <div class="col-lg-1 col-3 col-sm-3 col-md-2">
                                    <img src="../assets/images/maskGroup 29.png" class="img-fluid" />
                                </div>
                                <div class="col-lg-10 col-9 col-sm-9 col-md-9">
                                    <div class="row">
                                        <div class="col-lg-6 ">
                                    <p id="education_text" class="mb-0">Lecturer</p>
                                    <p class="mt-0 mb-0" id="institute_text">Adichunchanagiri Institute of Technology Mysore
                                        University</p>
                                    <p id="sub_text" class="mt-0">Chikmagalore, Karnataka, India.</p>
                                </div>
                                <div class="col-lg-6 text-center">
                                    <p id="sub_text">1987-1993 6yrs 02</p>
                                </div>
                                    </div>
                                </div>
                               
                            </div>
                            <div class="row" id="row_block">
                                <div class="col-lg-1 col-3 col-sm-3 col-md-2">
                                    <img src="../assets/images/maskGroup 29.png" class="img-fluid" />
                                </div>
                                <div class="col-lg-10 col-9 col-sm-9 col-md-9">
                                    <div class="row">
                                        <div class="col-lg-6 ">
                                    <p class="mb-0" id="education_text">Assistant Professor </p>
                                    <p class="mt-0 mb-0" id="institute_text">Jawaharlal Nehru National College of
                                        Engineering</p>
                                    <p class="mt-0" id="sub_text">Shimoga, Karnataka, India.</p>
                                </div>
                                <div class="col-lg-6 text-center">
                                    <p id="sub_text">1987-1993 6yrs 02</p>
                                </div>
                                    </div>
                                </div>
                               
                            </div>
                            <div class="row" id="row_block">
                                <div class="col-lg-1 col-3 col-sm-3 col-md-2">
                                    <img src="../assets/images/maskGroup 29.png" class="img-fluid" />
                                </div>
                                <div class="col-lg-10 col-9 col-sm-9 col-md-9">
                                    <div class="row">
                                        <div class="col-lg-6 ">
                                    <p class="mb-0" id="education_text">Professor </p>
                                    <p class="mt-0 mb-0" id="institute_text">Jawaharlal Nehru National College of
                                        Engineering</p>
                                    <p class="mt-0" id="sub_text">Shimoga, Karnataka, India.</p>
                                </div>
                                <div class="col-lg-6 text-center">
                                    <p id="sub_text">1987-1993 6yrs 02</p>
                                </div>
                                    </div>
                                </div>
                               
                            </div>
                            <div class="row" id="row_block">
                                <div class="col-lg-1 col-3 col-sm-3 col-md-2">
                                    <img src="../assets/images/maskGroup 29.png" class="img-fluid" />
                                </div>
                                <div class="col-lg-10 col-9 col-sm-9 col-md-9">
                                    <div class="row">
                                        <div class="col-lg-6 ">
                                    <p class="mb-0" id="education_text">Professor Head</p>
                                    <p class="mt-0 mb-0" id="institute_text">Jawaharlal Nehru National College of
                                        Engineering</p>
                                    <p class="mt-0" id="sub_text">Shimoga, Karnataka, India.</p>
                                </div>
                                <div class="col-lg-6 text-center">
                                    <p id="sub_text">1987-1993 6yrs 02</p>
                                </div>
                                    </div>
                                </div>
                               
                            </div>

                            <div class="row" id="row_block">
                                <div class="col-lg-1 col-3 col-sm-3 col-md-2">
                                    <img src="../assets/images/maskGroup 29.png" class="img-fluid" />
                                </div>
                                <div class="col-lg-10 col-9 col-sm-9 col-md-9">
                                    <div class="row">
                                        <div class="col-lg-6 ">
                                    <p class="mb-0" id="education_text">Professor Head</p>
                                    <p class="mt-0 mb-0" id="institute_text"> REVA Institute of Technology and Management
                                    </p>
                                    <p class="mt-0" id="sub_text">Bangalore, Karnataka, India.</p>
                                </div>
                                <div class="col-lg-6 text-center">
                                    <p id="sub_text">1987-1993 6yrs 02</p>
                                </div>
                                    </div>
                                </div>
                               
                            </div>


                            <div class="row" id="row_block">
                                <div class="col-lg-1 col-3 col-sm-3 col-md-2">
                                    <img src="../assets/images/maskGroup 29.png" class="img-fluid" />
                                </div>
                                <div class="col-lg-10 col-9 col-sm-9 col-md-9">
                                    <div class="row">
                                        <div class="col-lg-6 ">
                                    <p class="mb-0" id="education_text">Professor and Chief R&D Coordinator </p>
                                    <p class="mt-0 mb-0" id="institute_text"> M S Ramaiah Institute of Technology </p>
                                    <p class="mt-0" id="sub_text">Bangalore, Karnataka, India.</p>
                                </div>
                                <div class="col-lg-6 text-center">
                                    <p id="sub_text">1987-1993 6yrs 02</p>
                                </div>
                                    </div>
                                </div>
                               
                            </div>

                            <div class="row" id="row_block">
                                <div class="col-lg-1 col-3 col-sm-3 col-md-2">
                                    <img src="../assets/images/maskGroup 29.png" class="img-fluid" />
                                </div>
                                <div class="col-lg-10 col-9 col-sm-9 col-md-9">
                                    <div class="row">
                                        <div class="col-lg-6">
                                    <p class="mb-0" id="education_text">Professor and Chief R&D Coordinator </p>
                                    <p class="mt-0 mb-0" id="institute_text"> M S Ramaiah Institute of Technology </p>
                                    <p class="mt-0" id="sub_text">Bangalore, Karnataka, India.</p>
                                </div>
                                <div class="col-lg-6 text-center">
                                    <p id="sub_text">1987-1993 6yrs 02</p>
                                </div>
                                    </div>
                                </div>
                                
                            </div>

                            <div class="row" id="row_block">
                                <div class="col-lg-1 col-3 col-sm-3 col-md-2">
                                    <img src="../assets/images/maskGroup 29.png" class="img-fluid" />
                                </div>
                                <div class="col-lg-10 col-9 col-sm-9 col-md-9">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <p class="mb-0" id="education_text">Professor and Head, Industry Interaction
                                                Coordinator
                                            </p>
                                            <p class="mt-0 mb-0" id="institute_text">M S Ramaiah Institute of Technology</p>
                                            <p class="mt-0" id="sub_text">Bangalore, Karnataka, India.</p>
                                        </div>
                                        <div class="col-lg-6 text-center">
                                            <p id="sub_text">1987-1993 6yrs 02</p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="research_block">
                            <h2 class="Object_text"><img src="../assets/images/g2.png" class="img-fluid" /> RESEARCH </h2>

                            <div class="research_inner_block">
                                <h4 id="education_text"> Preamble:</h4>
                                <p>
                                    Development of technology in the domain of Communication Systems, Information and
                                    Computing that has given the way for integrated system design and development.
                                    Similarly, Rapid advances in modern high speed networks and wireless/Mobile networks,
                                    with the support of Internet growth, have produced tremendous research and commercial
                                    opportunities in the area of mobile multimedia Networks, ubiquitous and pervasive
                                    computing systems.
                                </p>
                                <p>

                                    Differentiated service or service subject to quality of service requirements and
                                    mobility of end users/terminals need software and/or hardware support at both
                                    intermediate and end systems, i.e., Routers, Mobile switching centers (MSC), base
                                    station (BS), Mobile terminals, etc. The increasing demand for such services has led to
                                    many new research challenges such as resource management for quality of service (QoS),
                                    admission control, location management, routing and mobile computing for mobile
                                    multimedia networking.
                                </p>
                                <p>
                                    My research interests include Resources management, Mobility management, Connectivity
                                    management and Dynamic routing in Mobile Adhoc and sensor networks and the applications
                                    of Computational Intelligence to tackle and solve some of the problems, that leads to
                                    optimization, function approximation and classification.
                                    One of the area is briefly discussed as a short introduction to our work. The most
                                    important challenges in Mobile Adhoc and Sensor Networks (WSNs) is to improve the
                                    operational efficiency and reliable data delivery in a highly resource constrained
                                    environment with dynamic and unpredictable behavior of network parameters and
                                    applications requirement.
                                </p>
                                <p>
                                    Swarm Computing, Game theoretic approach and dynamic Clustering with Computational
                                    Intelligence (heuristics) techniques are used for modeling, analyzing and designing of
                                    such networks. The work involves, the adoption of computational intelligence technique
                                    for the design and development of adaptive and dynamic algorithms, and systems. Also
                                    some of the works related to Protocol Engineering (Conformance testing and Test sequence
                                    generation) is carried out.
                                </p>
                                <p>
                                    Conformance testing for communication protocols is to test whether a protocol under
                                    test, conforms to the specifications laid down during the design phase. One of several
                                    works include, ''An optimal test sequence generation using Multiple Unique Input/Output
                                    sequences (MUIOS)''. Here, the test sequence generation problem using MUIOS is viewed as
                                    an asymmetric traveling sales person problem. This problem
                                </p>
                            </div>
                        </div>
                        <div class="research_block">
                            <h2 class="Object_text"><img src="../assets/images/g2.png" class="img-fluid" /> RESEARCH </h2>
                            <div class="research_inner_block">
                                <h4 id="education_text">Preamble:</h4>
                                <p>1. Contributor for the technical report submitted to Govt. of Telecom. for the Topic:
                                    DESIGN AND PLANNING SMART CITIES WITH IoT/ICT http://www.tec.gov.in/technical-reports/
                                </p>

                                <p>2. Naresh E., Vijaya Kumar B.P., Ayesha, Shankar S.P. (2020) Impact of Machine Learning
                                    in Bioinformatics Research. In: Statistical Modeling and Machine Learning Principles for
                                    Bioinformatics Techniques, Tools, and Applications. Algorithms for Intelligent Systems.
                                    Springer, Singapore. https://doi.org/10.1007/978-981-15-2445-5_4.
                                    https://link.springer.com/chapter/10.1007/978-981-15-2445-5_4 </p>

                                <p>3. Book Title: Handbook of Research on Deep Learning Innovations and Trends Release date
                                    - April' 2019 ch.8 - A Survey on Deep Learning Techniques Used for Quality Process
                                    https://www.igi-global.com/chapter/a-survey-on-deep-learning-techniques-used-for-qualityprocess/227848
                                </p>

                                <p>4. Book Title: Handbook of Research on Deep Learning Innovations and Trends Release
                                    date-April' 2019ch.15 - Anomaly Detection Using Deep Learning with Modular Networks
                                    https://www.igi-global.com/chapter/anomaly-detection-using-deep-learning-with-modularnetworks/227857
                                </p>

                                <p>5. A Survey on Artificial Intelligence Techniques Used in BioMetric Systems, C. N.
                                    Patill, E. Naresh, B. P. Vijay Kumar, and Prashanth Kambli, Intelligent Systems Advances
                                    in Biometric Systems, Soft Computing, Image Processing and Data Analytics.
                                    http://www.appleacademicpress.com/intelligent-systems-advances-in-biometricsystems-
                                    soft-computing-image-processing-and-data-analytics/9781771888004 </p>


                                <p>6. Naresh E, Vijaya Kumar B P, Aishwarya H and Jeevan, "Software Engineering in IoT"
                                    Copyright © 2019, IGI Global, DOI: 10.4018/978-1-5225-6070-8.ch008, 2019. https://
                                    www.igi-global.com/chapter/software-engineering-in-internet-of-things/210712 </p>

                                <p>7. Shantala Devi Patil, B.P. Vijayakumar and Kiran Kumari Patil, Fractal PKC-Based Key
                                    Management Scheme for Wireless Sensor Networks Recent Developments: Intelligent
                                    Computing, Communication and Devices AISC, volume 555 pp 121-128, Springer Print ISBN
                                    978-981-10-3778-8 Online ISBN 978-981-10-3779-5, 2017. </p>

                                <p>8.Vijaya Kumar B.P. And Sunil Kumar Manvi, “Proceedings of the National Conference on
                                    Computer Networks” (NCCN-09), February, 2009.</p>

                                <p>9. Vijaya Kumar B.P., Dilip Kumar S.M, Sriram, “Mobile Computing”, Published by Universal
                                    Education Trust for Kuvempu university, 2005. </p>

                                <p>10. Dasarathy B, Vijay Kumar B.P. and Sanjeev Kunte, “Emerging Trends in Human Machine.
                                    Interfaces (ICHMI-2004)”, Tata Mcgraw Hill, 2004, Proceedings of the International
                                    Con-ference on Human Machine Interfaces, (ICHMI' 2004), Indian Institute of Science,
                                    Bangalore, 2004. </p>

                            </div>
                        </div>


                    </el-tab-pane>
                    <el-tab-pane label="CONTACT" name="second">Config</el-tab-pane>
                    <el-tab-pane label="EDUCATION" name="third">Role</el-tab-pane>
                    <el-tab-pane label="EXPERIENCE" name="fourth">Task</el-tab-pane>
                    <el-tab-pane label="RESEARCH" name="fiveth">Role</el-tab-pane>
                    <el-tab-pane label="PUBLICATIONS" name="sixth">Task</el-tab-pane>
                    <el-tab-pane label="ADVISORY" name="seventh">Task</el-tab-pane>
                    <el-tab-pane label="SKILLS" name="eight">Role</el-tab-pane>
                    <el-tab-pane label="CONTRIBUTIONS" name="nine">Task</el-tab-pane>
                    <el-tab-pane label="PROJECTS" name="ten">Role</el-tab-pane>
                    <el-tab-pane label="RESEARCH" name="elven">
                        <h2>Research</h2>
                        <p>Development of technology in the domain of Communication Systems, Information and Computing that
                            has given the way for integrated system design and development. Similarly, Rapid advances in
                            modern high speed networks and wireless/Mobile networks, with the support of Internet growth,
                            have produced tremendous research and commercial opportunities in the area of mobile multimedia
                            Networks, ubiquitous and pervasive<br>computing systems. Differentiated service or service
                            subject to quality of service requirements and mobility of end users/terminals need software
                            and/or hardware support at both intermediate and end systems, i.e., Routers, Mobile switching
                            centers (MSC), base station (BS), Mobile terminals, etc. The increasing demand for such services
                            has led to many new research challenges such as resource management for quality of service
                            (QoS), admission control, location management, routing and mobile computing for mobile
                            multimedia networking.<br><br> My research interests include Resources management, Mobility
                            management, Connectivity management and Dynamic routing in Mobile Adhoc and sensor networks and
                            the applications of Computational Intelligence to tackle and solve some of the problems, that
                            leads to optimization, function approximation and classification. One of the area is briefly
                            discussed as a short introduction to our work. The most important challenges in Mobile Adhoc and
                            Sensor Networks (WSNs) is to improve the operational efficiency and reliable data delivery in a
                            highly resource constrained environment with dynamic and unpredictable behavior of network
                            parameters and applications requirement. Swarm Computing, Game theoretic approach and dynamic
                            Clustering with Computational Intelligence (heuristics) techniques are used for modeling,
                            analyzing and designing of such networks. The work involves, the adoption of computational
                            intelligence technique for the design and development of adaptive and dynamic algorithms, and
                            systems. Also some of the works related to Protocol Engineering (Conformance testing and Test
                            sequence generation) is carried out. Conformance testing for communication protocols is to test
                            whether a protocol under test, conforms to the specifications laid down during the design phase.
                            One of several works include, ''An optimal test sequence generation using Multiple Unique
                            Input/Output sequences (MUIOS)''. Here, the test sequence generation problem using MUIOS is
                            viewed as an asymmetric traveling sales person problem. This problem</p>
                    </el-tab-pane>
                </el-tabs>
            </section>

        
        </div>
        <Offer />
    </div>
</template>

<script>
import Offer from './Offer.vue'
export default {
    name: 'InstructorView',
    components: {
       
        Offer
    }
}
</script>


<style scoped>
.jk {
    padding-top: 5%;
    background: #EFF5FC 0% 0% no-repeat padding-box;
    opacity: 1;
}

@media only screen and (max-width: 600px) and (min-width: 100px) {
    .jk {
        padding-top: 22%;
    }
}

@media only screen and (max-width: 1024px) and (min-width: 650px) {
    .jk {
        padding-top: 10%;
    }
}

/* .user-img {
    width: 12%;
    height: 12%;
}
.col-md-5 img {
    float: left;
    width: 30%;
    height: 100%;
} */
/* .col-md-5 h5 p .social-icons {
    float: right;
    width: 70%;
    height: 100%;
} */

/* .col-md-5 h5 {
    margin-top: 5%;
} */
.social-icons .fa {
    padding: 10px;
    font-size: 14px;
    width: 35px;
    text-align: center;
    text-decoration: none;
    margin: 12px 10px 0px 0px;
    /* border-radius: 50%; */
    clip-path: circle();
}

.social-icons .fa:hover {
    opacity: 0.7;
}

.social-icons .fa-linkedin {
    background: #007bb5;
    color: white;
}

.social-icons .fa-facebook {
    background: blue;
    color: white;
}

.social-icons .fa-twitter {
    background: #55ACEE;
    color: white;
}

.share-icon {

    background-color: green;

    clip-path: circle();
    width: 40px;
    padding: 10px;
    text-align: right;
}

.professor-name .share-icon {
    float: right;
}

.professor-name .btn-group {
    float: right;
    margin-top: 10%;
    margin-right: -5%;
}

.professor-name .btn-group {
    background-color: #828282;
    border-top-left-radius: 2em 2em;
    border-top-right-radius: 2em 2em;
    border-bottom-right-radius: 2em 2em;
    border-bottom-left-radius: 2em 2em;
}

.professor-details {

    text-align: left;
    /* font: normal normal normal 12px/16px Segoe UI; */
    font-family: 'Open Sans', sans-serif;
    letter-spacing: 0px;
    color: #828282;
    opacity: 1
}

.icon {
    width: 25px;
    height: 25px;
    float: right;
    color: white;
}

.video {
    width: 50px;


}

.kl .card {
    padding: 10px 10px 0px;
    /* background-color: #8B8989; */

    color: black;
    cursor: pointer;
    /* background: radial-gradient(to right, darkblue, lightgray, blue); */
    box-shadow: 0px 0px 9px #000000A1;
    border: 1px solid #FFFFFF;

}

.mn p {
    float: left;
}

.mn img {
    float: right;
}

.mn1 i {
    float: left;
}

.mn1 p {
    float: right;
}

.card {
    border: 1px solid black;
    /* background: rgb(2,0,36);
    background: linear-gradient(180deg,lightblue 5%, blue, 20%, darkblue 100%);  */
    margin-bottom: 4%;
    margin-top: 20px;
    width: 100%;
    color: black;
    background: transparent radial-gradient(closest-side at 77% 22%, #FFFFFF 0%, #FAFAFA 0%, #F6F6F6 0%, lightgray 100%) 0% 0% no-repeat padding-box;
    box-shadow: 0px 0px 6px #000000CC;
    mix-blend-mode: luminosity;
    padding: 10px;

}

#small_text {
    text-align: right;
}

.video_logo {
    text-align: right;
}

.Object_text {
    color: #006acd;
    font-weight: bold;
    font-size: 20px;
    margin-bottom: 30px;
    font-family: 'Noto Sans', sans-serif;
    margin-top: 20px;
}

#Sub_text {
    color: #9E9E9E;
    padding-right: 20px;
}

.Sub_paragraph {
    color: #61646B;

}

.round_class {
    height: 20px;
    width: 20px;
    background: orange;
    border-radius: 50%;
    margin-left: 14px;

}

.line_class {
    width: 2px;
    height: auto;
    background: #0177FB;
    position: relative;
    top: 18px;
    left: -8px;
    /* bottom: 10px; */

}

.row_class {
    display: flex;
    margin-top: 12px;
}

#education_text {
    color: #61646B;
    font-family: 'Noto Sans', sans-serif;

    font-weight: 500;
}

.row_class i {
    padding: 4px 0px 0px 10px;
}

.experience_block,
.research_block {
    margin-top: 30px;
}

.Instructor_parent_block {
    max-width: 1300px;
    margin: 0 auto;
}

.professor_image_block {
    text-align: center;
}

#Course_section,
#non_course_section,
#tab_block {
    margin-top: 30px;
}

.el-tabs__content,
.education_block {
    margin-top: 30px;
}

.div {
    padding-left: 20px;
}

.ptext {
    margin-bottom: 15px;
}

@media screen and (max-width:767.98px) {
    #prof_text {
        font-size: 15px;
    }

    .instructor_head_text {
        font-size: 18px;

        text-align: center;
    }

    .professor-details_text {
        margin: 0;
    }

    .instructor_head_text,
    .course_text,
    .Object_text {
        font-size: 18px;
    }

    #education_text,
    #institute_text {
        font-size: 14px;
        margin-bottom: 0px;
    }

    .div p {
        font-size: 14px;
    }

    #sub_text {
        font-size: 14px;
        padding-right: 10px;
        margin-bottom: 0;
    }

    #education_text {
        font-weight: bold;
        color: #61646B;

    }

    #row_block {
        margin-top: 15px;
    }

    .Sub_paragraph,
    .research_inner_block p,
    .professor-details_text {
        font-size: 14px;
    }

    .rating_icons i {
        padding: 0;
    }



}

@media (min-width: 768px) and (max-width: 992px) {

    .Object_text {
        font-size: 18px;
    }
    #sub_text{
        margin-bottom:0;
    }
    #row_block{
        margin-top:15px;
    }
    #education_text{
        font-size:18px;
    }
}</style>