var SemesterDetails  = require('./SemesterDetails.json');
var StateManagement = require('./StateManagement.json');
// and so on

module.exports = function() {
return {
SemesterDetails  : SemesterDetails,
StateManagement  : StateManagement

// and so on
 }
}