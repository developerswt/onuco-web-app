<template>
    <div class="container">                  
     <div class="row dd">
                            <div class="col-lg-6 col-12 col-sm-12 col-md-6">
                                <div class="search_right_block">
                                    <h5 class="academic_head_text">

                                        <span id="aca_text">Maths 1 (NEP Series) </span>

                                    </h5>
                                    <div class="" >
                                    <p id="professor_text">Dr. Ashoka P R</p>
                                    <p>Course Description Course Description Course...</p>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4 col-md-3 col-6 col-sm-6 col-md-6">
                                           
                                            <p id="duration_text" class="mb-2"><img
                                                    src="../assets/images/Iconionic-ios-timer@2x.png"> 03h 32min</p>
                                        </div>
                                        <div class="col-lg-4 col-md-3  col-6 col-sm-6 col-md-6">
                                            <p id="module_text" class="mb-2"><img
                                                    src="../assets/images/Iconmap-school@2x.png"> 8 Modules
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 text-right col-12 col-sm-12 col-md-6">

                                <p id="review_text">2 min ago</p>
                                <div class="icon_blck">
                                    
                                    <i class="fa-solid fa-star" style="color: #ff9900;"></i>
                                    <i class="fa-solid fa-star" style="color: #ff9900;"></i>
                                    <i class="fa-solid fa-star" style="color: #ff9900;"></i>
                                    <i class="fa-solid fa-star" style="color: #ff9900;"></i>
                                    <i class="fa-solid fa-star" style="color: #ff9900;"></i>
                                    (23 Reviews)
                                </div>
                                
                                

                            </div>
                            
                        </div>
                        <div class="page footer" style=" border-top: 2px solid #BDC6CE;">
                        <p class="mt-4">Course Details</p>
                        <p>Course is expiring in 2 days Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        <p>Course is expiring in 2 days Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        <div class="text-right">
                            <p id="amount_text"><span id="strike_text"> &#8377;1,999</span>
                                    &#8377; 499<br>
                                    <button id="search_button" style=" color: #BDC6CE; border: 1px solid; position: inherit;left: 20px;">CANCEL</button>
                                <button id="search_button" style="background-color: #0177FB; color: white;">Renew</button></p>
                        </div>
                    </div>
                    </div>
</template>
<script>

</script>
<style scoped>

.dd{
    position: relative;
    top: 120px;
    margin-bottom: 160px;
}
</style>
