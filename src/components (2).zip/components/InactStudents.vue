<template>
    <div class="container" style="margin-top: 72px;">
   <div class="table-responsive">
               <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                   <thead>
                       <tr>
                           <th>ID</th>
                           <th>Name</th>
                           <th>Subject</th>
                           <th>Inactive</th>
                           
                       </tr>
                   </thead>
                       
               </table>
           </div>
           
           </div>
</template>
<script>

</script>
<style scoped>

</style>