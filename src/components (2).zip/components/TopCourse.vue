<template>
    <div class="category-test pt-3">
        <div class="container" style="margin-top: 70px;">
            <Breadcrumbs />
            <h4 class="academic_head_text pt-4">
                <span id="aca_text">Top</span>Rated Courses</h4>
        </div>
    </div>
    <div class="container mb ">
        <div class="row ">
            <div class="box ">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- <h5 class="card-title">JAVA Language</h5> -->
                        <p class="card-text">Data Management Sysyems & Visualization software developement</p>
                        <div class="text-left price" style="float: right;">
                           <p>&#8377;<del style="margin-right: 5px;">2099</del><b style="margin-right: 2px;">&#8377;1999</b></p>
                                
                            </div> <br>
                           <div class="row">
                            <div class="col-sm-6  star">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="col-sm-6" >
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                           </div>
                        </div>
 
                  
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <!-- <h5 class="card-title">JAVA Language</h5> -->
                        <p class="card-text">Data Management Sysyems & Visualization software developement</p>
                        <div class="text-left price" style="float: right;">
                           <p>&#8377;<del style="margin-right: 5px;">2099</del><b style="margin-right: 2px;">&#8377;1999</b></p>
                                
                            </div> <br>
                           <div class="row">
                            <div class="col-sm-6  star">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="col-sm-6" >
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                           </div>
                        </div>
 
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- <h5 class="card-title">JAVA Language</h5> -->
                        <p class="card-text">Data Management Sysyems & Visualization software developement</p>
                        <div class="text-left price" style="float: right;">
                           <p>&#8377;<del style="margin-right: 5px;">2099</del><b style="margin-right: 2px;">&#8377;1999</b></p>
                                
                            </div> <br>
                           <div class="row">
                            <div class="col-sm-6  star">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="col-sm-6" >
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                           </div>
                        </div>
 
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- <h5 class="card-title">JAVA Language</h5> -->
                        <p class="card-text">Data Management Sysyems & Visualization software developement</p>
                        <div class="text-left price" style="float: right;">
                           <p>&#8377;<del style="margin-right: 5px;">2099</del><b style="margin-right: 2px;">&#8377;1999</b></p>
                                
                            </div> <br>
                           <div class="row">
                            <div class="col-sm-6  star">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="col-sm-6" >
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                           </div>
                        </div>
 
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- <h5 class="card-title">JAVA Language</h5> -->
                        <p class="card-text">Data Management Sysyems & Visualization software developement</p>
                        <div class="text-left price" style="float: right;">
                           <p>&#8377;<del style="margin-right: 5px;">2099</del><b style="margin-right: 2px;">&#8377;1999</b></p>
                                
                            </div> <br>
                           <div class="row">
                            <div class="col-sm-6  star">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="col-sm-6" >
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                           </div>
                        </div>
 
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- <h5 class="card-title">JAVA Language</h5> -->
                        <p class="card-text">Data Management Sysyems & Visualization software developement</p>
                        <div class="text-left price" style="float: right;">
                           <p>&#8377;<del style="margin-right: 5px;">2099</del><b style="margin-right: 2px;">&#8377;1999</b></p>
                                
                            </div> <br>
                           <div class="row">
                            <div class="col-sm-6  star">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="col-sm-6" >
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                           </div>
                        </div>
 
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- <h5 class="card-title">JAVA Language</h5> -->
                        <p class="card-text">Data Management Sysyems & Visualization software developement</p>
                        <div class="text-left price" style="float: right;">
                           <p>&#8377;<del style="margin-right: 5px;">2099</del><b style="margin-right: 2px;">&#8377;1999</b></p>
                                
                            </div> <br>
                           <div class="row">
                            <div class="col-sm-6  star">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="col-sm-6" >
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                           </div>
                        </div>
 
                </router-link>
            </div>
            <div class="box">
                <router-link to="/Universities" style="text-decoration: none;">
                    <div class="wer">
                        <img class="card-img-top offer1" src="../assets/images/java.jpg" alt="Card image cap">
                        <div class="offer">
                            <img class="card-img-top" src="../assets/images/offer.png">
                        </div>
                        <div class="offer-details">
                            <font class="card-image-top"><b>20 % OFF</b></font>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- <h5 class="card-title">JAVA Language</h5> -->
                        <p class="card-text">Data Management Sysyems & Visualization software developement</p>
                        <div class="text-left price" style="float: right;">
                           <p>&#8377;<del style="margin-right: 5px;">2099</del><b style="margin-right: 2px;">&#8377;1999</b></p>
                                
                            </div> <br>
                           <div class="row">
                            <div class="col-sm-6  star">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            <div class="col-sm-6" >
                                <a href="#" class="btn btn-primary" >Buy Now</a>
                            </div>
                           </div>
                        </div>
 
                </router-link>
            </div>
        </div>
    </div>
</template>

<script>
import Breadcrumbs from './Breadcrumbs.vue'

export default {
    name: 'TopRatedCourse',
    components: {
        Breadcrumbs
    }
}
</script>



<style scoped>
.category-test a {
    text-decoration: none;
}

.category-test h4 a {
    float: right;
    color: #0d4b7e;
    font-size: 17px;
    font-family: 'Noto Sans', sans-serif;
  
}

/* .box .offer {
    width: 100px;
    height: 20px;
    position: relative;
    top: -177px;
    left: -5px;
    font-size: 12px;
} */
/* .offer-details {
    font-size: 12px;
    color: white;
    position: relative;
    top: -179px;
    left: -85px;
} */
/* .btn-warning {
    color: #fff;
    background-color: #f0ad4e;
    border-color: #eea236;
}
.btn {
    position: relative;
    left: 15%;
} */
/* .wr {
    position: relative;
    left: 9px;
    top: -4px;
    font-size: 12px;
} */
/* .box  offer {
    position: absolute;
    width: 10%;
    height: 7%;
    top: -10px;
    left: -4px;
    font-size: 12px;
} */

/* .box .card-text {
    font-size: 16px;
    font-family: 'Times New Roman', Times, serif;
    color: black;
} */
/* 
.box .card-title {
    font-size: 18px;
    font-family: 'Times New Roman', Times, serif;
    font-weight: bold;
    color: black;
    margin-top: -20px;
} */

.box .star {
    color: orange;
    position: relative;
    top: 8px;
    left: -29px;
    letter-spacing: 2px;
    display: flex;
}

.mb .row {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    flex-wrap: wrap;
    margin-left: 0px;
    margin-right: 0px;
    padding-top: 20px;
}

.box {

    height: 350px;
    /* UI Properties */
    width: 262px;
    /* border: 1px solid #FFFFFF; */
    cursor: pointer;
    background: #FFFFFF 0% 0% no-repeat padding-box;
    box-shadow: 0px 3px 6px #00000029;
    border-radius: 4px;
    opacity: 1;
    margin-bottom: 3%;
    

}

.box .row {
    padding: 12px 10px;
}



@media screen and (max-width: 600px) {
    .box {
        width: 100%;
        margin-bottom: 35px;
    }

    .box .offer {
        position: absolute;
        top: -13px;
    }

    .offer-details {
        position: relative;
        top: -200px;
    }

    .academic_head_text {
        font-size: 15px !important;
        padding-left: 0 !important;

    }

    .category-test h4 a {
        padding-right: 0;
        font-size: 15px !important;
    }
}

@media only screen and (min-width: 600px) and (max-width: 912px) {
    .box {
        width: 47%;
        margin-bottom: 35px;
    }
}

@media only screen and (min-width: 950px) and (max-width: 1024px) {
    .box {
        width: 30%;
        margin-bottom: 3%;
    }
}

@media (min-width: 768px) and (max-width: 991.92px) {
    .academic_head_text {
        font-size: 20px;
    }

}

.price p {
    color: black;
    float: left;
    width: 35%;
}

.price a {
    width: 60%;
    float: right;

}

.offer {
    position: absolute;
    width: 90px;
    height: 10px;
    top: -12px;
    left: -5px;

}

.offer-details {
    position: absolute;
    top: -10px;
    left: 5px;
    color: white;
    font-size: 14px;
}

.wer {
    position: relative;
}

.academic_head_text {
    color: #006acd;
    /* padding-left:20px; */
    font-size: 20px;

}


#aca_text {
    color: #006acd;
    font-weight: bold;
    padding-right: 10px;
}
.box .card-text {
    font: var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-normal) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-21) var(--unnamed-font-family-segoe-ui);
    letter-spacing: var(--unnamed-character-spacing-0);
    text-align: left;
    font: normal normal normal 16px/21px Segoe UI;
    letter-spacing: 0px;
    color: #666666;
    opacity: 1;
}
.box .card-title {
    margin-top: -20px;
    font: var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-600) var(--unnamed-font-size-16)/var(--unnamed-line-spacing-21) var(--unnamed-font-family-segoe-ui);
    letter-spacing: var(--unnamed-character-spacing-0);
    text-align: left;
    font: normal normal 600 16px/21px Segoe UI;
    letter-spacing: 0px;
    color: #666666;
    opacity: 1;
}
.btn{
    width: 120px; 
    height: 37px;
    margin-left: 10px; 
    margin-left: 28px;
}

.card-body{
    padding: 1rem;
}
@media screen and(max-width: 1024px) {
.btn{
   
    margin-left: 115px;
    margin-top: 0px;
}

.box{
height: 392px;
}

}
@media only screen and (min-width: 280px) and (max-width: 700px) {
    .btn{ 
    margin-left: 169px;
    margin-top: -30px;

} 
.box{
height: 382px;
}
.box .star {
    color: orange;
    position: relative;
    top: 8px;
    left: -12px;
    letter-spacing: 2px;
    display: flex;
}
}
.container{
    padding-bottom: 20px;
}
@media(mix-width: 920px) {
.container{
    padding-bottom: 9rem;
max-width: 0px;
}

}


</style>

