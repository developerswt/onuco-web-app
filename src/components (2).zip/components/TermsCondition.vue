<template>
    <div class="container">
        <div class="jk">
            <h2>Terms and Conditions Generator</h2>
            <p>Every website needs a Terms and Conditions. Even if your website is not for your business or any commercial structure, you will be better off with a Terms and Conditions agreemnent. All websites are advised to have their own agreements for their own protection.</p>

            <p>We will help you by providing this FREE terms and conditions generator. Fill in the blank fields below, and we will email you your personalized terms and conditions just for you and your business. The accuracy of the generated document on this website is not legally binding. Use at your own risk.</p>

            <p><b>Looking for a Privacy Policy?</b>. Check out GDPR & CCPA Privacy Policy Generator.</p>
        </div>
    </div>
</template>

<script>

export default {
    name: 'TermsCondition'
}
</script>

<style scoped>
.jk {
    margin-top: 8%;
}
</style>