<template>
    <div class="container">
        <div class="row rr">
            <div class=" col-lg-9">
                <p style="color: #0066CC;"><b>Available </b>Semesters (03)</p>
        
            </div>
            <div class=" col-lg-3  text-right">
                <button class="bt">Renew</button>   
            </div>
        </div>
        <div class="card" >
            <div class="card-body">
                <div class="paym row ">
                    <div class=" col-md-6 col-sm-6">
                        <label> 
                            <input type="checkbox">  
                                1ST SEMESTER
                        </label>
                    </div> 
                    <div class="col-md-2 col-sm-2">
                        <p><b>₹1,920</b></p>
                    </div>
                    <div class="col-md-2 col-sm-2">
                        <p><del>₹7,996</del></p>
                    </div>
                    <div class="col-md-2 col-sm-2">
                        <p style="color: #07750F;" >76% OFF</p>
                    </div>

   
                </div>
                <div class="row" style=" border-top: 2px solid #BDC6CE;">
                <div class="col-md-6 col-sm-6">
                    <label> 
                        <input type="checkbox">  
                        MATH 1 (NEP SERIES)
                    </label>
                </div> 
                <div class="col-md-2 col-sm-2">
                    <p><b>₹1,920</b></p>
                </div>
                <div class="col-md-2 col-sm-2">
                    <p><del>₹7,996</del></p>
                </div>
                <div class="col-md-2 col-sm-2">
                    <p style="color: #07750F;" >76% OFF</p>
                </div>
            </div>
        <div class="row">
            <div class="col-md-6 col-sm-6">
                <label> 
                    <input type="checkbox">  
                        MATH 1 (RYFS SERIES)
                </label>
            </div> 
            <div class="col-md-2 col-sm-2">
                <p><b>₹1,920</b></p>
            </div>
            <div class="col-md-2 col-sm-2">
                <p><del>₹7,996</del></p>
            </div>
                <div class="col-md-2 col-sm-2">
                    <p style="color: #07750F;" >76% OFF</p>
    </div>

   
</div>
<div class="row">
    <div class="col-md-6 col-sm-6">
        <label> 
            <input type="checkbox">  
            C PROG (95 SERIES) 
        </label>
    </div> 
        <div class="col-md-2 col-sm-2">
            <p><b>₹1,920</b></p>
        </div>
        <div class="col-md-2 col-sm-2">
            <p><del>₹7,996</del></p>
        </div>
        <div class="col-md-2 col-sm-2">
<p style="color: #07750F;" >76% OFF</p>
</div>

   
</div>
<div class="row">
    <div class="col-md-6 col-sm-6">
        <label> 
            <input type="checkbox">  
            SOM (NEP SERIES)
        </label>
    </div> 
        <div class="col-md-2 col-sm-2">
            <p><b>₹1,920</b></p>
        </div>
        <div class="col-md-2 col-sm-2">
            <p><del>₹7,996</del></p>
        </div>
        <div class="col-md-2 col-sm-2">
<p style="color: #07750F;" >76% OFF</p>
</div>

   
</div>
            </div>

        </div>
        <div class="card mt-3">
            <div class="card-body">
   <div class="row">
    <div class="col-md-6 col-sm-6">
        <label> 
            <input type="checkbox">  
            2ND SEMESTER
        </label>
    </div> 
    </div>
    </div>
    </div>
    <div class="card mt-3">
            <div class="card-body" >
   <div class="row">
    <div class="col-md-6 col-sm-6">
        <label> 
            <input type="checkbox">  
            3RD SEMESTER
        </label>
    </div> 
    </div>
    </div>
    </div>
    <div class="card mt-3" style=" border-radius:0.25rem; margin-bottom: 30px;  ">
            <div class="card-body">
   <div class="row">
        <div class="col-md-6 col-sm-6">
            <p>Selected subject's price</p>
        </div> 
        <div class="col-md-6 col-sm-6 text-right">
            <p>₹1999</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-6">
            <p>Discount</p>
        </div> 
    
        <div class="col-md-6 col-sm-6 text-right">
            <p style="color: #07750F;">-₹1999</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-6">
            <p><b>Total Amount</b></p>
        </div> 
    
        <div class="col-md-6 col-sm-6 text-right">
            <p>₹1999</p>
        </div>
    </div>
    <div class="col-md-6 col-sm-6">
       <p style="color: #07750F;">You will save ₹1052 on this order</p>
    </div> 
    </div>
    </div>
   
    </div>
    <div class="container-fluid"></div>
</template>
<script>

</script>
<style scoped>
.bt{
    background-color: #0177FB;
    color: white;
    
}
.rr{
    position: relative;
    top:100px;
    margin-bottom: 105px;
}
.card{
    border-radius: 1.25rem;
    font-size: 14px;
}

.card-body {
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 0.6rem 1.25rem 0rem;
}

@media (max-width:520px) {
    .row {
    
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap:inherit !important;
    margin-right: -15px;
    margin-left: -15px;
}
.card{
    border-radius: 1.25rem;
    font-size: 10px;
}
    
}

.container-fluid {
    width: 100%;
    height: 120px;
    background-image: url('../assets/images/Group 246.png');
}
</style>
