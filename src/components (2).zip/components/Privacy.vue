<template>
    <div class="container">
        <div class="jk">
            <h2><b>Privacy Policy Generator</b></h2>
            <p>Not everyone knows how to make a Privacy Policy agreement, especially with <b>CCPA</b> or <b>GDPR</b> or <b>CalOPPA</b> or <b>PIPEDA</b> or <b>Australia's Privacy Act</b> provisions. If you are not a lawyer or someone who is familiar to Privacy Policies, you will be clueless. Some people might even take advantage of you because of this. Some people may even extort money from you. These are some examples that we want to stop from happening to you.</p>

            <p>We will help you protect yourself by generating a Privacy Policy.</p>

            <p><b>Our Privacy Policy Generator can help you make sure that your business complies with the law.</b> We are here to help you protect your business, yourself and your customers.</p>

            <p>Fill in the blank spaces below and we will create a personalized website Privacy Policy for your business. No account registration required. <b>Simply generate & download a Privacy Policy in seconds!</b></p>

            <p>Small remark when filling in this Privacy Policy generator: Not all parts of this Privacy Policy might be applicable to your website. When there are parts that are not applicable, these can be removed. Optional elements can be selected in step 2. The accuracy of the generated Privacy Policy on this website is not legally binding. Use at your own risk.</p>

            <p>Looking for Terms and Conditions?<router-link to="/Terms">Check out Terms and Conditions Generator.</router-link></p>
        </div>
    </div>        
</template>

<script>

export default {
    name: 'PrivacyView'
}
</script>

<style scoped>
.jk {
    margin-top: 8%;
}
</style>